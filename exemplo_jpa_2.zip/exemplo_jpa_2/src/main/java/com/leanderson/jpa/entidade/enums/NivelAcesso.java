package com.leanderson.jpa.entidade.enums;

public enum NivelAcesso {
    VISUALIZADOR,
    COLABORADOR,
    ADMINISTRADOR
}
