package com.leanderson.jpa.entidade.enums;

public enum StatusTarefa {
    PENDENTE,
    EM_PROGRESSO,
    CONCLUIDA,
    CANCELADA
    }
