package com.leanderson.jpa.entidade.enums;

public enum Prioridade {
    BAIXA,
    MEDIA,
    ALTA
}
